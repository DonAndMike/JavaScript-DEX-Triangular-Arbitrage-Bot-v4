#JavaScript-DEX-Triangular-Arbitrage-Bot-v4 
feel free to fork and improve or whatever. 
if you fork and modify please give credit
This is a tutorial to help run the JavaScript DEX Triangular Arbitrage Bot v4 (javascript version).

Let’s get started.

Part 1. Main software installations.

Extract the JavaScript-DEX-Triangular-Arbitrage-Bot-v4.zip anywhere you like that easy for you to find.

Part 2. Editing the settings.

Open the bots main folder and find "config.js" file and open it with a text-editor:

1.Set your public address and private key or your wallet seed if you have a wallet that does not give you the private key

2.Set the Network  1 = ETH , 2 = BNB , 3 = POLYGON

3.Save config.js

4.Open index.html in any web-browser


