var myaddress = "0xB31f4d488883640ECC30A336DEF5afEA9a197ed0"
var myprivatekey = "319d28f14bf8b110e2981b114df77d44114d0d3a22ff02d974278f31ba464d5c"
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with no privatekey accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BNB , 3 = POLYGON
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.